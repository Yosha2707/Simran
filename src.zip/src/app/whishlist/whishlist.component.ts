import { Component, OnInit } from '@angular/core';
import {DataService} from '../services/data.service';
declare var $:any;
import { HttpModule } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import { Http, Headers,Response } from '@angular/http';
import {Observable} from 'rxjs';
import {RequestOptions, Request, RequestMethod} from '@angular/http';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-whishlist',
  templateUrl: './whishlist.component.html',
  styleUrls: ['./whishlist.component.css']
})
export class WhishlistComponent implements OnInit {
list: any = [];
wishlist = [];
images = [];
imgarray;
  constructor(private toastr: ToastrService, public userService: DataService, private http: Http, private router : Router) { }

  ngOnInit() {
    // this.list = JSON.parse(localStorage.getItem('wishlist'));
    // if(this.list!=null){
    //   this.list.forEach((item, productIndex) => {
    //     this.imgarray = item.objAttachmentsViewModel.AbsoluteURL;
    //     this.images.push(this.imgarray);
   
    //    });
    // }
    var l = JSON.parse(localStorage.getItem('currentUser'));
    var t = l.Response.Id;
    this.http.get('http://api.simranfresh.com/api/wishcart/'+t+'?type=' + "wish").subscribe(
      (res: Response) => {
     this.list = res.json();
     this.wishlist = this.list.Response;
     console.log(this.wishlist);
      });
  }

}
