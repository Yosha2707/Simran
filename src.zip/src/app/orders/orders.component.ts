import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
allorder = false;
pendingorder = false;
completedorder = false;
basket = true;
  constructor() { }

  ngOnInit() {
  }

  allOrder(){
     this.allorder = true;
     this.pendingorder = false;
     this.completedorder = false;
     this.basket = false;
    // alert(this.allorder)
  }

  pendingOrder(){
     this.pendingorder = true;
     this.allorder = false;
     this.completedorder = false;
     this.basket = false;
  }
  completedOrder(){
     this.completedorder = true;
     this.pendingorder = false;
     this.allorder = false;
     this.basket = false;
  }
}
