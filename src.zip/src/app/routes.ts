import {Routes} from '@angular/router'
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
//import { VegetablesComponent } from './vegetables/vegetables.component';
//import { FruitsComponent } from './fruits/fruits.component';
import { FooterComponent } from './footer/footer.component';
import { CartComponent } from './cart/cart.component';
import { SigninComponent } from './signin/signin.component';
import { SignupComponent } from './signup/signup.component';
import { AuthGuard } from './auth/auth.guard';
import { MyaccountComponent } from './myaccount/myaccount.component';
import { OrdersComponent } from './orders/orders.component';
import { TcComponent } from './tc/tc.component';
import { PrivacyComponent } from './privacy/privacy.component';
import { ContactComponent } from './contact/contact.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { WhishlistComponent } from './whishlist/whishlist.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';

export const appRoutes : Routes = [
    {path : 'homeauth' , canActivate:[AuthGuard], component : HomeComponent},
    {path : '' , component : HomeComponent},
   // {path:'products', component:VegetablesComponent}, 
    {path : 'home' , component : HomeComponent},
  //  {path : 'fruits' , component : FruitsComponent},
    {path : 'cart' , component : CartComponent},
    {path : 'login' , component : SigninComponent},
    {path : 'signup' , component : SignupComponent},
    {path : 'myaccount' , component : MyaccountComponent},
    {path : 'Orders' , component : OrdersComponent},
    {path : 'terms' , component : TcComponent},
    {path : 'policy' , component : PrivacyComponent},
    {path : 'contact' , component : ContactComponent},
    {path : 'out' , component : CheckoutComponent},
    {path : 'wish' , component : WhishlistComponent},
    {path : 'changepassword' , component : ChangepasswordComponent},
    {path : 'updateprofile' , component : UpdateprofileComponent},
    
  
];