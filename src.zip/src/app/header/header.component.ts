import {
  Component,
  OnInit,
  Input
} from '@angular/core';
import {
  HostListener,
  Inject
} from "@angular/core";
import {
  Http,
  Headers,
  Response,
  RequestOptions,
  Request,
  RequestMethod,
  HttpModule
} from '@angular/http';
import {
  DataService
} from '../services/data.service';
import 'rxjs/add/operator/toPromise';
import {
  Observable
} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import {
  ActivatedRoute,
  Router
} from '@angular/router';
import {
  Location
} from '@angular/common';
declare var gapi: any;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  myImage: string = "http://localhost:4200/assets/img/slider/slide-1.jpg";
  scroll: boolean = false;
  productCartArray = [];
  taxes;
  total;
  productQuantity = 1;
  Price;
  shipping = 100;
  totalprice = 0;
  // i;
  cartCount;
  currentuser;
  demo: any = [];
  @Input()
  parentCount: number;

  @Input()
  cartData:any = [];

  @Input()
  totalpricee:any = [];

  constructor(private router: Router) {
  }

  ngOnInit() {
    
    this.cartCount = localStorage.getItem('cartcount');
    this.currentuser = localStorage.getItem('currentUser');
    this.productCartArray = JSON.parse(localStorage.getItem('session'));
    if(this.productCartArray!=null){
      this.productCartArray.forEach((item, productIndex) => {
        this.Price = item.Price
        this.productCartArray[productIndex].productQuantity = this.productQuantity;
        this.productCartArray[productIndex].finalPrice = this.productQuantity * this.Price;
  
      });
      this.productCartArray.forEach((element, index) => {
        this.totalprice = this.totalprice + element.finalPrice;
      });
     this.total = this.totalpricee;
      
      
   }
   
  }


  @HostListener("window:scroll", [])
  onWindowScroll() {
    const number = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    if (number > 50) {
      return this.scroll = true;
    } else {
      return this.scroll = false;
    }

  }

  remove(data, index) {
    // localStorage.clear();
    var a = JSON.parse(localStorage.getItem('session'));
    var b = JSON.parse(localStorage.getItem('cartcount'));
    var c = b - 1;
    console.log(a)
    a.splice(index, 1);
    localStorage.setItem('session', JSON.stringify(a));
    localStorage.setItem('cartcount', JSON.stringify(c));
    this.refresh();

  }

  refresh(): void {
    window.location.reload();
  }


  home() {
    this.router.navigate(['/home']);
    this.refresh();
  }

  account() {
    var user = localStorage.getItem('currentUser');
    if (user) {
      this.router.navigate(['/myaccount'])
    } else {
      this.router.navigate(['/login'])
    }
  }




}

