import { Component, OnInit } from '@angular/core';
import {DataService} from '../services/data.service';
declare var $:any;
import { HttpModule } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import { Http, Headers,Response } from '@angular/http';
import {Observable} from 'rxjs';
import {RequestOptions, Request, RequestMethod} from '@angular/http';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],


})
export class CartComponent implements OnInit {
  productCartArray = [];
  c = [];
  price = [];
  final_price;
  Price;
  totalprice = 0;
  sum = 0;
  variable;
  productQuantity = 1;
  taxes;
  shipping = 100;
  total;
  cartCoount;
  res: Float64Array;
p = [];
  constructor(private toastr: ToastrService, public userService: DataService, private http: Http, private router : Router) {
    this.cartCoount = localStorage.getItem('cartcount');
  }
  refresh(): void {
    window.location.reload();
  }


  remove(data, index) {
    // localStorage.clear();
    var a = JSON.parse(localStorage.getItem('session'));
    var b = JSON.parse(localStorage.getItem('cartcount'));
    var c = b-1;
    console.log(a)
    a.splice(index, 1);
    localStorage.setItem('session', JSON.stringify(a));
    localStorage.setItem('cartcount', JSON.stringify(c));
    this.refresh();

  }



  ngOnInit() {
    var l = JSON.parse(localStorage.getItem('currentUser'));
    var t = l.Response.Id;
    this.http.get('http://api.simranfresh.com/api/wishcart/'+t+'?type=' + "cart").subscribe(
      (res: Response) => {
     this.p = res.json();
    this.productCartArray = this.p["Response"]
    console.log(this.productCartArray);
      });

   // this.productCartArray = JSON.parse(localStorage.getItem('session'));
  if(this.productCartArray!=null){
    this.productCartArray.forEach((item, productIndex) => {
      this.Price = item.Price;
     this.productQuantity = this.productCartArray[productIndex].prodQty;
       this.productCartArray[productIndex].finalPrice = this.productQuantity * this.Price;
   });
   this.productCartArray.forEach(element => {
     this.totalprice += element.finalPrice || 0;
   });
   this.taxes = this.totalprice/20;
   this.total = this.totalprice + this.taxes + this.shipping;
  }
  
  }

  calculateProductPrice(productQty, productIndex) {
	console.log(productIndex, productQty);
  this.productCartArray[productIndex].productQuantity = productQty;
	this.productCartArray[productIndex].finalPrice = productQty * this.Price;
  this.final_price = this.productCartArray[productIndex].finalPrice;
	console.log(this.productCartArray);
	this.calculateTotalPrice();
	console.log(this.totalprice);
  }

  calculateTotalPrice() {
	this.totalprice = 0;
	this.productCartArray.forEach(element => {
    this.totalprice += element.finalPrice || 0;
  });
  this.taxes = this.totalprice/20;
  this.total = this.totalprice + this.taxes + this.shipping;
  };

}

