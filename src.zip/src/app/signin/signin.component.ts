import { Component, OnInit, NgZone } from '@angular/core';
import { DataService } from '../services/data.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import {AuthGuard} from '../auth/auth.guard';
import { HttpModule } from '@angular/http';
import { Http, Headers, Response } from '@angular/http';
import {RequestOptions, Request, RequestMethod} from '@angular/http';
import * as AOS from 'aos';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  readonly rootUrl = 'http://api.simranfresh.com/api/signin';
isLoggedIn: boolean = false;
loading = false;
canActivate = false;
logininfo;
Google;
passToken;
Signin = true;
googleuser;
forgotPemail;
constructor(ngZone: NgZone, private toastr: ToastrService, private http: Http, private userService: DataService, private router:Router, public AuthGuard: AuthGuard) {
  window['onSignIn'] = (user) => ngZone.run(() => this.onSignIn(user));
 }


  ngOnInit() {
    AOS.init();
      gapi.signin2.render('my-signin2', {
        'scope': 'profile email',
        'width': 300,
        'height': 35,
        'longtitle': true,
        'theme': '',
       
      });
    
  }

  onSignIn(googleUser) {
    var profile = googleUser.getBasicProfile();
    console.log(profile);
    this.googleuser = {
      "UserName": profile.getName(),
      "Email":profile.getEmail(),
      "GoogleId":profile.getId()
    
  }
  console.log(this.googleuser);
  this.http.post("http://api.simranfresh.com/api/signup", this.googleuser).subscribe((res: Response) => {
  console.log(res)  
  localStorage.setItem('currentUser', JSON.stringify(this.googleuser));
  this.router.navigate(['/myaccount']);
    
  },
  error => {
    this.toastr.error('Something Wrong happened..!!');
    this.userService.error(error);
  });
  }

   
  OnLogin(userName, password) {
  
    var date = new Date();
    this.logininfo = {
      "UserName": userName,
      "UserPassword":password,
      "IsRemberMe":"false"
    }
    let headers = new Headers({ "content-type": "application/json", });
    let options = new RequestOptions({ headers: headers });
    this.http.post(this.rootUrl,this.logininfo, options)
       .map(res => res.json())
       .subscribe(
                 data => {
                   console.log(data)
                   this.isLoggedIn = true;
                   if(data.Status==true){
                    localStorage.setItem('currentUser', JSON.stringify(data));
                   this.router.navigate(['/myaccount']);
                   }
                   else{
                    this.toastr.error('Wrong Id or Password..!!');
                   }
    },
  
    error => {
  
      this.userService.error(error);
      this.loading = false;
    });

          
  }
  signup(){
    this.router.navigate(['/signup']);
  }

  forgotPassword(data){
    this.forgotPemail = {
      "UserName":data
    }
    
    let headers = new Headers({ "content-type": "application/json", });
    let options = new RequestOptions({ headers: headers });
    this.http.post("http://api.simranfresh.com/api/forgetpassword", this.forgotPemail, options)
    .map(res => res.json())
    .subscribe((res:Response) => {
    console.log(res)  
    this.toastr.success('Email Sent successfully..!!'); 
    },
    error => {
      this.toastr.error('Please Enter Registered Email..!!'); 
     
    });
 
  }

}
