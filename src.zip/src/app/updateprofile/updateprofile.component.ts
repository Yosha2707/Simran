import { Component, OnInit } from '@angular/core';
import {DataService} from '../services/data.service';
declare var $:any;
import { HttpErrorResponse } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import { Http, Headers,Response } from '@angular/http';
import {Observable} from 'rxjs';
import {RequestOptions, Request, RequestMethod} from '@angular/http';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-updateprofile',
  templateUrl: './updateprofile.component.html',
  styleUrls: ['./updateprofile.component.css']
})
export class UpdateprofileComponent implements OnInit {
userData;
Email;
FullName;
Mobile;
Profile= true;
Cpassword = false;
Cities;
City;
Branches;
Branch;
Zones;
Zone;
ZoneId;
BranchId;
CityId;
oldPassword;
newPassword;
confirmPassword;
resetPasswordData;
UserId;
updateProfileData;
fullName;
Address;
GST;
  constructor(private toastr: ToastrService, private userService: DataService, private http: Http, private router : Router) { }

  ngOnInit() {
    this.userData = JSON.parse(localStorage.getItem('currentUser'));
    console.log(this.userData.Response)
    this.Email = this.userData.Response.Email;
    this.Mobile = this.userData.Response.MobileNo;
    this.UserId = this.userData.Response.Id;
    this.http.get('http://api.simranfresh.com/api/City').subscribe(
      (res: Response) => {
     this.Cities = res.json();
     this.City = this.Cities.Response
      });

      this.http.get('http://api.simranfresh.com/api/branchmaster/0').subscribe(
        (res: Response) => {
       this.Branches = res.json();
       this.Branch = this.Branches.Response
      // console.log(this.Branch)
        });

        this.http.get('http://api.simranfresh.com/api/zonesmaster/0').subscribe(
          (res: Response) => {
         this.Zones = res.json();
         this.Zone = this.Zones.Response
        // console.log(this.Zone)
          });

//console.log(this.Id);
//console.log(this.BranchId);
//console.log(this.ZoneId);
  }

  profile(){
this.Profile = true;
this.Cpassword = false;
  }

  cpassword(){
this.Cpassword = true;
this.Profile = false;
  }

  changePassword(){
    this.resetPasswordData = {
      "UserName": this.Email,
      "userId": this.UserId,
      "OldPassword": this.oldPassword,
      "NewPassword": this.newPassword,
      "ConfirmPassword": this.confirmPassword
    }
    let headers = new Headers({ "content-type": "application/json", });
    let options = new RequestOptions({ headers: headers });
    this.http.post("http://api.simranfresh.com/api/myprofile", this.resetPasswordData, options)
    .map(res => res.json())
    .subscribe(
      data => {
        console.log(data)
    this.toastr.success("Password Changed Successfully..!!")
},

error => {
  console.log(error._body["objErrorInfo"])
this.toastr.error(error._body.objErrorInfo.ErrorMessage)
this.userService.error(error);
});
  }

  updateProfile(){
    console.log(this.UserId);
    console.log(this.fullName);
    console.log(this.Email);
    console.log(this.Mobile);
    console.log(this.Address);
    console.log(this.GST);
    console.log(this.ZoneId);
    console.log(this.BranchId);
    console.log(this.CityId);

    this.updateProfileData = {
      "UserId": this.UserId,
      "FullName": this.fullName,
      "Email": this.Email,
      "MobileNo": this.Mobile,
      "Address":this.Address,
      "GSTNumber": this.GST,
      "ZoneId": this.ZoneId,
      "BranchId":this.BranchId,
      "CityId":this.CityId

    }
      const url = `${"http://api.simranfresh.com/api/updatemyprofile"}`;
     // console.log(this.Id)
       let headers = new Headers();
       headers.append('Content-Type', 'application/json');
      this.http.put(url, this.updateProfileData, {headers:headers})
      .map(res => res.json())
      .subscribe((res:Response) => {
      console.log(res)  
      this.toastr.success('Profile Updated successfully..!!');
  
      });  
  
  }

}
