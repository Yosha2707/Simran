import { Component, OnInit } from '@angular/core';
import {DataService} from '../services/data.service';
declare var $:any;
import { HttpModule } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import { Http, Headers,Response } from '@angular/http';
import {Observable} from 'rxjs';
import {RequestOptions, Request, RequestMethod} from '@angular/http';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-fruits',
  templateUrl: './fruits.component.html',
  styleUrls: ['./fruits.component.css'],
  providers: [DataService]
})
export class FruitsComponent implements OnInit {
  DataArray: any = [];
  array:any [];
  fruitObj: any;
  updatedArray:any = [];
  public cartCoount;
  public cartCount;
veg: any = [];
list:any = [];
z = [];
x = [];
preview: any = [{
  "Id": 0,
  "ProductCategoryId": 0,
  "UoMId": 0,
  "Name": "",
  "ImageUpload": "",
  "HSNCode": "",
  "MinQuantity": 0,
  "IsActive": false,
  "Description": "",
  "ProductCategoryName": null,
  "UoMName": null,
  "Price": null,
  "objProdCatTaxesVM": [],
  "objAttachmentsViewModel": {
    "Id": 0,
    "EntityType": 0,
    "EntityId": 0,
    "Title": "",
    "AttachmentUniqueId": "",
    "Description": null,
    "Tag": null,
    "FileName": "",
    "FileExt": "",
    "MediaType": "",
    "MediaString": null,
    "IsTempAttachment": false,
    "AbsoluteURL": "",
    "SubCategoryName": null,
    "CreatedDate": "",
    "CreatedBy": 0,
    "ModifiedDate": "",
    "ModifiedBy": 5
  },
  "CreatedDate": "",
  "CreatedBy": 0,
  "ModifiedDate": "",
  "ModifiedBy": 0
}];
imgPreview: any;
  constructor(private toastr: ToastrService, public userService: DataService, private http: Http, private router : Router) {
    this.cartCoount = localStorage.getItem('cartcount');
    var l = JSON.parse(localStorage.getItem('currentUser'));
    var t = l.Response.Id;
    this.http.get('http://api.simranfresh.com/api/wishcart/'+t+'?type=' + "wish").subscribe(
      (res: Response) => {
     this.z = res.json();
    this.x = this.z["Response"]
    console.log(this.x);
      });
    this.fruitObj = {
      "Id":null,
      "ChildId":null,
      "Name":null,
      "Description":null,
      "MinDesired":null,
      "MaxDesired":null,
      "IsActive":true,
      "PageCount":null,
      "PageSize":null,
      "TopSearch":"Fruits",
      "ChildName":null,
      "UoMName":null,
      "ProdCat":"2",
      "From":null,
      "To":null,
      "FirmName":null,
      "ContactPerson":null,
      "Address":null,
      "MobileNo":null,
      "Landline":null,
      "Email":null,
      "GSTNo":null,
      "CustomerCategoryId":null,
      "ZoneId":null,
      "CustomerCategoryName":null,
      "ZoneName":null
    }
    let headers = new Headers({ "content-type": "application/json", });
    let options = new RequestOptions({ headers: headers });
    this.http.post("http://api.simranfresh.com/api/productprices", this.fruitObj, options)
    .map(res => res.json())
    .subscribe((res:Response) => {
    console.log(res)  
    this.DataArray = res;
    this.array = this.DataArray.Response

    }); 
  }

  ngOnInit() {
  }

  cartdata(data, dataQty) {
    let id = data.Id;
    let a = [];
    let z =[];
    a = JSON.parse(localStorage.getItem('session'));
    if(a==null){
      z.push(data)
      localStorage.setItem('session', JSON.stringify(z));
    }
    else{
      a.push(data);
      localStorage.setItem('session', JSON.stringify(a));
    }
    
    this.updatedArray = JSON.parse(localStorage.getItem('session'));
    console.log(this.updatedArray);
    localStorage.setItem('cartcount', JSON.stringify(this.updatedArray.length));
    this.cartCoount = this.updatedArray.length;

    this.updatedArray.forEach((item, productIndex) => {
    if(item.Id==id){
      item.prodQty = dataQty;
    }
   });
   
  localStorage.setItem('session', JSON.stringify(this.updatedArray));
   var aaa = JSON.parse(localStorage.getItem('session'));
   console.log(aaa);
   this.toastr.success('Added to cart successfully..!!'); 
     
  }

  productPreview(data) {
    this.http.get('http://api.simranfresh.com/api/product/' + data).subscribe(
      (res: Response) => {
        console.log(res)
        this.veg = res.json();
        this.preview = this.veg.Response;
        this.imgPreview = this.preview.objAttachmentsViewModel.AbsoluteURL;
      });
  }

  refresh(): void {
    window.location.reload();
  }

  whishlist(data){
    var l = JSON.parse(localStorage.getItem('currentUser'));
    var t = l.Response.Id;
    var a = [];
    this.list = {
      "Id":0,
      "UserId":l.Response.Id,
      "WishCartType": "wish",
      "ProductId": data.Id,
      "Quantity": 1,
      "CreatedDate":data.CreatedDate  ,
      "ProductName": data.Name,
      "Description": data.Description,
      "HSNCode": data.HSNCode,
      "MinQuantity": data.MinQuantity,
      "Price": data.Price,
      "UnitName": data.UoMName,
    }
    console.log(this.x);
    this.x.push(this.list)
    console.log(this.x);
  const url = `${"http://api.simranfresh.com/api/wishcart"}`;
   let headers = new Headers();
   headers.append('Content-Type', 'application/json');
  this.http.put(url, this.x , {headers:headers})
  .map(res => res.json()) 
   .subscribe(
    data => {
      console.log(data)
      this.toastr.success('Added to Wishlist successfully..!!'); 
      this.refresh();
},

error => {
this.userService.error(error);
});
  }

}


