import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';
import { Http, Headers, Response } from '@angular/http';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import 'rxjs/add/operator/map';
import {User} from './user.model';
import { Subject } from 'rxjs/Subject';
import {AuthGuard} from '../auth/auth.guard';
import {RequestOptions, Request, RequestMethod} from '@angular/http';
import { VegetablesComponent } from '../vegetables/vegetables.component';
import { HeaderComponent } from '../header/header.component';
import { ViewChild } from '@angular/core'
declare var $:any;
import { HttpModule } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class DataService {
  readonly rootUrl = 'https://api.simranfresh.com/api/account';
  private subject = new Subject<any>();
  private keepAfterNavigationChange = false;

  constructor(private http: Http, public AuthGuard: AuthGuard, private toastr: ToastrService, public userService: DataService, private router : Router) {
   
   }

  private headers = new Headers({ 'Content-Type': 'application/json' });

  registerUser(userData): Observable<any> {
    alert("services called")
    return this.http.post('http://api.simranfresh.com/api/signup/', userData);

  } 

  userAuthentication(username: string, password: string) {
    let headers = new Headers({ "content-type": "application/json", });
    let options = new RequestOptions({ headers: headers });
    this.http.post(this.rootUrl,
       { UserName: username, UserPassword: password, IsRememberMe:null, Lastlogin:null }, options)
       .map(res => res.json())
    .subscribe((res:Response) => {
   return res;
    });
  }
  
  error(message: string, keepAfterNavigationChange = false) {
    this.keepAfterNavigationChange = keepAfterNavigationChange;
    this.subject.next({ type: 'error', text: message });
  }


}
