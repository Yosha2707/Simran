import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
Sucess = false;
Normal = true;
Danger = false;
  constructor() { }

  ngOnInit() {
  }
sucess(){
  this.Normal = false;
  this.Sucess = true;
  this.Danger = false;
}

danger(){
  this.Normal = false;
  this.Sucess = false;
  this.Danger = true;
}

}
