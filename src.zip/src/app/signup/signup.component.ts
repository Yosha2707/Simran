import { Component, OnInit } from '@angular/core';
import {User} from '../services/user.model';
import {NgForm} from '@angular/forms'
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { DataService } from '../services/data.service';
import {ToastrService} from 'ngx-toastr';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
  providers:[DataService]
})
export class SignupComponent implements OnInit {

  register;
  emailPattern:"^[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}$";
  constructor(private toastr: ToastrService, private userService: DataService,  private router:Router) { }

  ngOnInit() {
    this.register = {
      UserName : '',
      UserPassword: '',
      ConfirmPassword: '',
      FullName:'',
      MobileNo:'',
      GoogleId:'null',
      FacebookId:'null'
    };
  }

  registerUser(){
    alert("registerUser")
    this.userService.registerUser(this.register).subscribe(
      response =>{
        this.toastr.success('User '+this.register.UserName + 'has been created')
      },
        error => console.log('error', error)
       
        
    );

}

login(){
  this.router.navigate(['/login']);
}

}
